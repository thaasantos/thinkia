import type React from "react"
import type { Metadata } from "next"
import { Oswald, Montserrat } from "next/font/google"
import "./globals.css"

const oswald = Oswald({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-oswald",
})

const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-montserrat",
})

export const metadata: Metadata = {
  title: "Thinkia - Landing Pages de Alta Conversão para Profissionais da Saúde",
  description:
    "Transforme visitantes em pacientes pagantes com landing pages que falam a língua do seu cliente ideal. Especialistas em São Caetano do Sul.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" className={`${oswald.variable} ${montserrat.variable}`}>
      <body>{children}</body>
    </html>
  )
}
