"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import {
  Clock,
  DollarSign,
  MessageCircle,
  Smartphone,
  Target,
  CheckCircle,
  Star,
  Users,
  Zap,
  TrendingUp,
  Shield,
} from "lucide-react"

export default function ThinkiaLanding() {
  const [vagasRestantes, setVagasRestantes] = useState(7)

  useEffect(() => {
    // Simula atualização do contador de vagas
    const interval = setInterval(() => {
      setVagasRestantes((prev) => (prev > 3 ? prev - 1 : 3))
    }, 300000) // Atualiza a cada 5 minutos

    return () => clearInterval(interval)
  }, [])

  const scrollToOffer = () => {
    document.getElementById("oferta")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-sm border-b border-purple-500/20">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Image src="/thinkia-logo-hq.png" alt="Thinkia" width={240} height={80} className="h-16 w-auto" />
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Clock className="w-4 h-4 text-purple-400" />
            <span className="text-purple-400">{vagasRestantes} vagas restantes este mês</span>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center relative overflow-hidden pt-20">
        {/* Background 3D Elements */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-r from-purple-600/30 to-pink-600/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        <div className="container mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center relative z-10">
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight font-oswald">
                Profissionais da saúde em <span className="text-purple-400">São Caetano</span>: pare de queimar dinheiro
                em tráfego que <span className="text-purple-400">não converte</span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed font-montserrat">
                Transforme visitantes em pacientes pagantes com uma landing page que fala a língua do seu cliente ideal
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={scrollToOffer}
                className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 transform hover:scale-105"
              >
                QUERO MINHA VAGA AGORA
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="w-full h-96 relative flex items-center justify-center">
              {/* Background glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-full blur-3xl animate-pulse"></div>

              {/* Hero Star Image */}
              <div className="relative z-10 animate-float">
                <Image
                  src="/thinkia-star.png"
                  alt="Thinkia Star"
                  width={400}
                  height={400}
                  className="w-auto h-80 drop-shadow-2xl"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problema Section */}
      <section className="py-20 bg-white text-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 font-oswald">
              Reconhece esses <span className="text-purple-600">problemas</span>?
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <DollarSign className="w-12 h-12 text-purple-600" />,
                title: "Gasto alto em tráfego que não converte",
                description: "Investimento em anúncios sem retorno",
              },
              {
                icon: <MessageCircle className="w-12 h-12 text-purple-600" />,
                title: "Horas perdidas no WhatsApp",
                description: "Tentando convencer clientes que não estão prontos",
              },
              {
                icon: <Smartphone className="w-12 h-12 text-purple-600" />,
                title: "Dificuldade para criar conteúdo",
                description: "Que realmente funciona e converte",
              },
              {
                icon: <Target className="w-12 h-12 text-purple-600" />,
                title: "Não saber falar a 'língua' do cliente",
                description: "Comunicação que não ressoa com o público",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="p-8 text-center hover:shadow-xl transition-all duration-300 border-purple-100"
              >
                <div className="flex justify-center mb-6">{item.icon}</div>
                <h3 className="text-xl font-bold mb-4 font-montserrat">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Solução Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl lg:text-5xl font-bold mb-8 font-oswald">
              A <span className="text-purple-400">solução</span> que você estava procurando
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed mb-12 font-montserrat">
              Criamos landing pages que quebram as objeções dos seus clientes ANTES deles chegarem no seu WhatsApp. É
              como traçar o ICP perfeito e falar de igual para igual - não adianta falar francês com quem fala italiano.
            </p>

            <div className="grid md:grid-cols-3 gap-8 mt-16">
              {[
                {
                  icon: <Users className="w-16 h-16 text-purple-400" />,
                  title: "ICP Perfeito",
                  description: "Identificamos exatamente quem é seu cliente ideal",
                },
                {
                  icon: <Zap className="w-16 h-16 text-purple-400" />,
                  title: "Conversão Otimizada",
                  description: "Páginas que convertem visitantes em pacientes",
                },
                {
                  icon: <TrendingUp className="w-16 h-16 text-purple-400" />,
                  title: "Resultados Garantidos",
                  description: "ROI comprovado para profissionais da saúde",
                },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-6">{item.icon}</div>
                  <h3 className="text-2xl font-bold mb-4 text-white">{item.title}</h3>
                  <p className="text-gray-400">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Credibilidade Section */}
      <section className="py-20 bg-white text-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 font-oswald">
              Já funciona para <span className="text-purple-600">profissionais da região</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Instituto Caldeira",
                description: "Nutricionista do Rodrigo Faro",
                result: "+ conversões",
              },
              {
                name: "Qualivida Saúde",
                description: "Bem Estar e Qualidade de Vida",
                result: "+ leads qualificados",
              },
              {
                name: "Espaço Cerâmica",
                description: "Profissionais confiam no nosso trabalho",
                result: "Resultados consistentes",
              },
            ].map((case_, index) => (
              <Card key={index} className="p-8 text-center hover:shadow-xl transition-all duration-300">
                <div className="flex justify-center mb-4">
                  <Star className="w-8 h-8 text-yellow-500 fill-current" />
                </div>
                <h3 className="text-xl font-bold mb-2 font-montserrat">{case_.name}</h3>
                <p className="text-gray-600 mb-4">{case_.description}</p>
                <p className="text-purple-600 font-bold">{case_.result}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Oferta Section */}
      <section id="oferta" className="py-20 bg-gradient-to-br from-purple-900 to-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center space-x-2 bg-red-600 text-white px-6 py-2 rounded-full mb-6">
                <span className="text-2xl">🔥</span>
                <span className="font-bold">OFERTA EXCLUSIVA SÃO CAETANO</span>
              </div>
              <h2 className="text-4xl lg:text-5xl font-bold mb-4 font-oswald">
                APENAS <span className="text-purple-400">10 VAGAS</span> ESTE MÊS
              </h2>
              <p className="text-xl text-gray-300 font-montserrat">
                "Aceito apenas 10 projetos mensais para garantir qualidade máxima e acompanhamento personalizado"
              </p>
            </div>

            <Card className="p-8 bg-white/10 backdrop-blur-sm border-purple-400/30">
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold mb-4 text-white">Landing Page Completa + ICP Personalizado</h3>
                <div className="flex items-center justify-center space-x-4 mb-6">
                  <span className="text-2xl text-gray-400 line-through">DE: R$1.100</span>
                  <span className="text-4xl font-bold text-purple-400">POR: R$800</span>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="text-2xl font-bold mb-6 text-center text-purple-400">
                  BÔNUS EXCLUSIVOS PARA SÃO CAETANO:
                </h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-400" />
                    <span>Mapeamento completo do seu ICP (valor R$300)</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-400" />
                    <span>Análise estratégica do seu Instagram (valor R$200)</span>
                  </div>
                </div>
              </div>

              <div className="text-center mb-8">
                <p className="text-xl mb-2">
                  <span className="text-gray-400">VALOR TOTAL: R$1.300</span> |{" "}
                  <span className="text-purple-400 font-bold">VOCÊ PAGA: R$800</span>
                </p>
                <p className="text-sm text-gray-400">(O investimento se paga em apenas um dia de atendimento*)</p>
              </div>

              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center space-x-2 bg-red-600 text-white px-8 py-3 rounded-lg mb-4 font-bold text-lg">
                  <span>⏰</span>
                  <span>RESTAM APENAS {vagasRestantes} VAGAS ESTE MÊS</span>
                </div>
              </div>

              <div className="text-center">
                <Link
                  href="https://wa.me/5511999999999?text=Oi!%20Vim%20da%20sua%20página%20e%20quero%20garantir%20minha%20vaga%20também!"
                  target="_blank"
                >
                  <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-12 py-6 text-xl font-bold rounded-lg transition-all duration-300 transform hover:scale-105">
                    QUERO MINHA VAGA NO WHATSAPP
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Processo Section */}
      <section className="py-20 bg-white text-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 font-oswald">
              Como <span className="text-purple-600">funciona</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                number: "1",
                icon: <Target className="w-12 h-12 text-purple-600" />,
                title: "Mapeamento do seu ICP",
                description: "Identificamos seu cliente ideal (gratuito)",
              },
              {
                number: "2",
                icon: <Zap className="w-12 h-12 text-purple-600" />,
                title: "Criação da landing page",
                description: "Desenvolvemos em poucas horas",
              },
              {
                number: "3",
                icon: <TrendingUp className="w-12 h-12 text-purple-600" />,
                title: "Página pronta para converter",
                description: "Seus visitantes viram pacientes",
              },
            ].map((step, index) => (
              <div key={index} className="text-center relative">
                <div className="w-16 h-16 bg-purple-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.number}
                </div>
                <div className="flex justify-center mb-6">{step.icon}</div>
                <h3 className="text-2xl font-bold mb-4 font-montserrat">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Garantia Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center mb-8">
              <Shield className="w-20 h-20 text-purple-400" />
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-8 font-oswald">
              <span className="text-purple-400">Garantia</span> de qualidade
            </h2>
            <p className="text-2xl text-gray-300 mb-12 font-montserrat">
              "Se você não aprovar a landing page, refazemos até ficar perfeita*"
            </p>

            <Card className="p-8 bg-purple-900/20 border-purple-400/30">
              <h3 className="text-2xl font-bold mb-4 text-purple-400">Por que apenas 10 vagas?</h3>
              <p className="text-xl text-gray-300">
                Porque qualidade não se negocia. Cada projeto recebe atenção 100% personalizada.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-to-br from-purple-900 to-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold mb-8 font-oswald">
            Não perca sua <span className="text-purple-400">vaga</span>
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto font-montserrat">
            Transforme seu negócio hoje mesmo. Apenas {vagasRestantes} vagas restantes este mês.
          </p>

          <Link
            href="https://wa.me/5511999999999?text=Oi!%20Vim%20da%20sua%20página%20e%20quero%20garantir%20minha%20vaga%20também!"
            target="_blank"
          >
            <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-16 py-8 text-2xl font-bold rounded-lg transition-all duration-300 transform hover:scale-105 mb-4">
              GARANTIR MINHA VAGA AGORA
            </Button>
          </Link>

          <p className="text-sm text-gray-400 mt-4">
            *Baseado no ticket médio dos profissionais da região. Refação conforme contrato.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-black border-t border-purple-500/20">
        <div className="container mx-auto px-4 text-center">
          <Image
            src="/thinkia-logo-hq.png"
            alt="Thinkia"
            width={240}
            height={80}
            className="h-16 w-auto mx-auto mb-4"
          />
          <p className="text-gray-400">© 2024 Thinkia. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
